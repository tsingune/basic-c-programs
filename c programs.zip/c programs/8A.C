#include<stdio.h>
void dummy(float *a)
{ float b=*a;
dummy(&b);
}
struct student
{
	char name[100];
	int roll;
	float fee;
}s[5];
int main()
{
	FILE *p;
	int i;
	clrscr();
	p=fopen("STUD.txt","w");
	if(p==NULL)
	{
       printf("error! unable to load file");
       return 0;
	}
	for(i=0;i<5;i++)
	{    getchar();
		printf("\nenter the info of student %d",i+1);
		printf("\nenter name:\t");
		gets(s[i].name);
		printf("\nenter the roll number:\t");
		scanf("%d",&s[i].roll);
		printf("\nenter the fee:\t");
		scanf("%f",&s[i].fee);
		fprintf(p, "%s\n",s[i].name);
		fprintf(p, "%d\n",s[i].roll );
		fprintf(p, "%f\n",s[i].fee );
	}
	fclose(p);
	getch();
	return 0;
}