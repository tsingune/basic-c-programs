#include<stdio.h>
#include<math.h>
void main()
{ int n;
  float s,a,b,c,d,area,pm,t;
  printf("enter the no:of sides(>=3 and <5):\t");
  scanf("%d",&n);
  switch(n)
  { case 3:{
  	         printf("enter the valuue of sides:\n");
  	         scanf("%f %f %f",&a,&b,&c);
  	         s=(a+b+c)/2;
  	         area=sqrt(s*(s-a)*(s-b)*(s-c));
  	         printf("area is %f \n",area );
  	         pm=a+b+c;
  	         printf("perimeter is %f \n",pm);
  	         break;
            }
    case 4:{
             printf("enter the value of sides\n");
             scanf("%f %f %f %f",&a,&b,&c,&d);
             s=(a+b+c+d)/2;
             printf("enter the sum of 2 opposite angles:\t");
             scanf("%f",&t);
             area=sqrt((s-a)*(s-b)*(s-c)*(s-d)-a*b*c*d*cos(t*3.14/360)*cos(t*3.14/360));
             printf("area is %f\n",area );
             pm=a+b+c+d;
             printf("perimeter is %f\n",pm );
             break;
             }
    default:{
              printf("enter valid sides\n");
            }         

    }
  }

	


}