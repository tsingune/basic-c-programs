#include<stdio.h>
#include<conio.h>
int main()
{   int a,b,c;
    clrscr();
    printf("enter the value of a:");
    scanf("%d",&a);
    printf("\nenter the value of b:");
    scanf("%d",&b);
    printf("\nenter the value of c:");
    scanf("%d",&c);
    if(a!=b && a!=c && b!=c)
      printf("\n1");
      else
      printf("\n0");
    getch();
	return 0;
}