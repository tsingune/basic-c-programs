#include<stdio.h>
struct student
{
	int roll;
	char name[100];
	float m1;
	float m2;
	float m3;
};
void main()
{
	struct student s[5];
	int i;
	float avg;
	clrscr();
	for(i=0;i<5;i++)
	{         getchar();
      printf("\n enter student %d info:",i+1);
      printf("\n enter name of student:\t");
      gets(s[i].name);
      printf("\nenter roll number:\t");
      scanf("%d",&s[i].roll);
      printf("\nenter marks of 1:\t");
      scanf("%f",&s[i].m1);
      printf("\nenter marks of 2:\t");
      scanf("%f",&s[i].m2);
      printf("\nenter marks of 3:\t");
      scanf("%f",&s[i].m3);
      printf("\n");
	}
	for(i=0;i<5;i++)
	{
       printf("\n student %d info is:",i++);
       printf("\n name is : %s",s[i].name);
       printf("\nroll number is: %d",s[i].roll);
       printf("\nmarks of 1 is: %f",s[i].m1);
       printf("\nmarks of 2 is: %f",s[i].m2);
       printf("\nmarks of 3 is: %f",s[i].m3);
       avg=(s[i].m1+s[i].m2+s[i].m3)/3.0;
       printf("\naggregate marks is: %f",avg);
	}
	getch();
}