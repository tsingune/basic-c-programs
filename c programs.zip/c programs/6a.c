#include<stdio.h>
#include<string.h>
void rev(char a[]);
void main()
{
	char a[50];
	printf("enter the string:\t\n");
	gets(a);
	rev(a);
	printf("reverse string is: %s\n",a);
}
void rev(char a[])
{ int l,i,c=0;
	char t;
	l=strlen(a);
	c=l-1;
	for (i = 0; i < l/2; i++,c--)
	{
		t=a[i];
		a[i]=a[c];
		a[c]=t;
	}
}