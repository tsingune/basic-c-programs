#include<stdio.h>
long int power(int x,int y);
void main()
{
	int m,n;
	long int r;
	printf("\nenter the base number:\t");
	scanf("%d",&m);
	printf("\n enter the exponent:"\t);
	scanf("%d",&n);
	r=power(m,n);
	printf("answer is %ld\n",r );
}
long int power(int x, int y)
{ 
   if(y==0)
   	return 1;
   else 
   	return x*power(x,y-1);

}