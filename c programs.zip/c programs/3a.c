#include<stdio.h>
#include<conio.h>
void main()
{
  int sum=0,number=0;
  printf("enter -9999 to stop the loop\n");
  do
  {
     sum=sum+number;
     printf("enter an integer to perform sum\n");
     scanf("%d",&number);
  }while(number!=-9999);
	printf("sum=%d\n",sum);
}