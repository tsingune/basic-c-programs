#include<stdio.h>
int gcd(int x,int y);
void main()
{
	int a,b,r;
	printf("\nenter any 2 positive integers:\t");
	scanf("%d %d",&a,&b);
	r=gcd(a,b);
	printf("\n gcd of %d and %d is %d",a,b,r);
}
int gcd(int x, int y)
{ if(x==0)
	return y;
   if(y==0)
   	return x;
   if(x>y)
   	return gcd(x-y,y);
   if(x<y)
   	return gcd(x,y-x);

}