#include<stdio.h>
void dummy(float *a)
{ float b=*a;
dummy(&b);
}
struct student
{
	char name[100];
	int roll;
	float fee;
}s[5];
int main()
{
	FILE *p;
	int i;
	clrscr();
	p=fopen("STUD.txt","r");
	if(p==NULL)
	{
       printf("error! unable to load file");
       return 0;
	}
	for(i=0;i<5;i++)
	{   
		
		fscanf(p, "%s",&s[i].name);
		fscanf(p, "%d",&s[i].roll );
		fscanf(p, "%f",&s[i].fee );
		printf("\nname is %s",s[i].name);
		printf("\nroll number is %d",s[i].roll);
		printf("\nfee paid is %f",s[i].fee);

	}
	fclose(p);
	getch();
	return 0;
}