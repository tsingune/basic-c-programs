$include<stdio.h>
void copy(char *p,char*q);
void main()
{
	char s[100],t[100];
	printf("enter the string to be copied:\t");
	gets(s);
	copy(s,t);
	printf("copied string is: %s",t);
}
void copy(char *p,char *q)
{
	while(*p!='\0')
	{
		*q=*p;
		p++;
		q++;
	}
	*q='\0';
}