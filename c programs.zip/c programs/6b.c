#include<stdio.h>
void area(int r,int h,float *area);
void vol(int r,int h,float *vol);
void main()
{
	int r,h;
	float ar,v;
	printf("enter the radius of culinder:\t");
	scanf("%d",&r);
	printf("enter the height of cylinder:\n");
    scanf("%d",&h);
    area(r,h,&ar);
    vol(r,h,&v);
    prinntf("\n The surface area of the cylinder: %f\t",ar);
    printf("\nthe volume of the cylinder: %f\t\n",v);
}

void area(int r,int h,float *area)
{
   *area=2*3.14*r*r;
}
void vol(int r,int h,float *vol)
{

	*vol=2*3.14*r*r*h;
}