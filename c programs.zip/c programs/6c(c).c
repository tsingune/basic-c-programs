#include<stdio.h>
long int fibo(int n);
void main()
{
	int n;
	long int f;
	printf("enter the value of n for n'th term:\t");
	scanf("%d",&n);
	f=fibo(n);
	printf("%d term is %ld\n",n,f);
}
 long int fibo(int n)
{
	if(n==0)
	return 0;
	else if(n==1)
	return 1;
	else
	return fibo(n-1)+fibo(n-2);
}