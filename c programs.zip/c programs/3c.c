#include<stdio.h>
void main()
{
  int sp,c,i,j;
  for(i=1;i<=4;i++)
  {
    for(sp=1;sp<=4-i;sp++)
    	printf("");
   c=0;
   for (j =1; j <2*i-1; j++)
   {
   	  if(j<=i)
   	  {
        printf("%d",i+c);
        c++;
   	  }
   	  else
   	  { c--;
   	  	printf("%d",i+c-1);
   	  }
   }
   printf("\n");
  }


}