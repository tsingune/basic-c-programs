#include <stdio.h>
void main()
{ int n,i,f,l,m;
   float a[100],key;
   printf("enter the size of array:\t");
   scanf("%d",&n);
   printf("enter the elements in sorted order:\n");
   for ( i = 0; i < n; i++)
   {
      printf("enter element %d:",i++ );
      scanf("%f",&a[i]);
   }
   printf("enter the element to be sorted:\t");
   scanf("%f",&key);
   f=0;
   l=n-1;
   while(f<=l)
   { m=(f+l/2);
      if(a[m]==key)
      {
         printf("the element %f is present at the location %d\n",key,m+1 );
         break;
      }
      else if(a[m]>key)
         l=m-1;
      else
         f=m+1;
   }
   if(f>l)
      printf("the element %f is not present \n",key );
}