#include<stdio.h>
void main()
{
	int n,i,ch,r,rev=0,sum=0.n2;
	printf("enter the 4 digit number:\t");
	scanf("%d",&n);
	n1=n;
	printf("enter 1 to revere the number\n");
	printf("enter 2 to find the sum of the digits\n");
    printf("enter yout choice:\t");
    scanf("%d"&ch);
    switch(ch)
    {  case 1: {
    	        while (n>0)
                 {   r=n%10;
                 	 rev=rev*10+r;
                 	 n=n/10;
                 }

                 printf("reverse of %d is %d \n",n1,rev);
                  break;
                }
       case 2:{
       	         while(n>0)
       	         {
       	         	r=n%10;
       	         	sum+=r;
       	         	n/=10;
       	         }
       	         printf("sum of digits of %d is %d\n",n1,sum);
       	         break;
               }
       default:
                {
                   printf("enterd choice is invalid\n");

                }
    }

}