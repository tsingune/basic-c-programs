#include<stdio.h>
#include<math.h>

void main()
{int i,n,c,r,result;
	i=10;
	while(i<999999)
	{
      n=i;
      result=0;
      c=0;
      while(n>0)
     {
        n=n/10;
        c++;
     }
     n=i;
     while(n>0)
     {
       r=n%10;
       result=result+pow(r,c);
      n=n/10;
     }
     if(result==i)
     {
       printf("%d is Armstrong no:\n",i );
     }
     i++;
	}
}